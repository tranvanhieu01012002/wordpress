<?php
return array(
    '0'=> 'Chủ Nhật',
    '1'=> 'Hai',
    '2'=> 'Ba',
    '3'=> 'Tư',
    '4'=> 'Năm',
    '5'=> 'Sáu',
    '6'=> 'Bảy',
)
?>